In order to check this homework properly, please start with ADS_hw5_Terzikj_Dushan.pdf file. From there on out, please follow the instructions in the file and read the comments carefully in the source files in order to understand the algorithm implemented.

In order to compile the .cpp source files, please type make in the console. In order to run the programs please type ./[name_of_program] in the console. 
