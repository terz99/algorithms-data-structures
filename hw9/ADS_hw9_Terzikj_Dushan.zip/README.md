For easier checking of my homework, please start with the file "solution_detailed.pdf" and follow the instructons.

I wrote the coding assignments in Python 3, therefore you would need python3.6 interpreter to run it correctly. You can see
that the Makefile uses python3.6. 