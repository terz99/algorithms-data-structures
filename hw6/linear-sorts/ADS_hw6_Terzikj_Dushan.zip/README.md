In order to check the homework properly, please start with the file 'ADS_hw6_Terzikj_Dushan.pdf' and follow the instructions properly. 

There are some source files in the homework as well, along with a Makefile. In order to compile the source files (.cpp), please type 'make' in the console. In order to run them type ./[name_of_program] in the console. Read the comments carefully in order to understand the code. 
