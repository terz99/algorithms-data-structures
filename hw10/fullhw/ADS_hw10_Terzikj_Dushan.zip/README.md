For fully check my homework, please start with the file solution_detailed.pdf. From there on, please follow the instructions in that file.

How to use the Makefile:
make            - to compile all 3 problems
make run-p1     - to compile and run problem 1
make run-p2     - to compile and run problem 2
make run-p3     - to compile and run problem 3
make clean      - to clean the folder