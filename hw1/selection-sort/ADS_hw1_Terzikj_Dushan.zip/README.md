Start reading ADS-assignment1-Dushan-Terzikj.pdf and follow instructions on how to check.

selection-sort.cpp is the algorithm with stdin
selection-sort-random.cpp is the algorithm with randomized input
output.txt are results from randomized sequences
best_cases.txt are results from best case sequences
worst_case.txt are results from worst case sequences
script.m is a Matlab/Octave script used to plot the data from the .txt files
plot.pdf is a pdf version of the running time plot

