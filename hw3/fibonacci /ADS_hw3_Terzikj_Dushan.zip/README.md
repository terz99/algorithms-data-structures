In order to check my homework properly, please start reading the ADS_hw3_Terzikj_Dushan.pdf file. From there on, just follow the instructions properly. 

NOTE FOR THE PLOT: The plot has been plotted using matlab/octave. Closed form and matrix method have very similar running times (both O(lg(N))) and they coincide with the plot, that is why you cannot see one of the lines. Y-axis is the time in seconds and x-axis is the size of N (in log(N), base 10)
