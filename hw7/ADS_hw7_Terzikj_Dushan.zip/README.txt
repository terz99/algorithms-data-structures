NOTE: All the source files contain documentation inside the source files. Due to lack of doxygen knowledge, I could not generate proper 
documentation of the code. Everything you need to know is explained before every method implementation. Please read them carefully to ensure 
easier homework checking.

Each directory contains a Makefile, therefore by typing 'make' into a terminal, all the source files will be compiled and with typing 'make run'
you will run the main() method in the test source files. If the test case design implemented in the test source files are not compatible with
your test cases, then please write your own script. The type of test cases were not specified in the homework. 

Start with the file 'ADS_hw7_Terzikj_Dushan.pdf' and follow the instructions from there.