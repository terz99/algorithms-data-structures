#include <bits/stdc++.h>

#ifndef _SOLUTION_H
#define _SOLUTION_H

class Solution{

    const static int INF = (1 << 30); // Big integer representing infinity

public: 

    
};

#endif