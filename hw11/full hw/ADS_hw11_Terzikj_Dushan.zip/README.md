In order to correctly check my homework, please use the submission format that you specified in the assignment sheet.

In order to compile the source code, type 'make' without quotes in a terminal. To run the tasks use 'make run-p2', 'make run-p3' or 'make run-p4', without quotes, depends on which task you want to run. 